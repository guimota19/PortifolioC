#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	
	int x;
	x = 10;
	
	int *ponteiro;
	ponteiro = &x;
	
	printf("%i\n", *ponteiro);	// imprimira o valor 10
	
	printf("%i\n", ponteiro); // imprimira o valor de memoria
	
	
	return 0;
}
