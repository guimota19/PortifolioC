#include <stdio.h>
#include <stdlib.h>

/* 
ATIVIDADE 1
USANDO PONTEIROS A ESTRUTURA CIRE UM PROGRAMA PARA IMPRINIR NA TELA HORA, MINUTOS E SEGUNDOS.
OBS: OS VALORES PODEM SER PREDETERMINADOS EX: 20:20:20

ATIVIDADE 2
CRIAR UM PROGRAMA USANDO PONTEIRO E ESTRUTURA PARA REALIZAR OPERA��ES MATEM�TICAS EM HORAS, MINUTOS E SEGUNDOS
- Horas - soma do valor 100 ao valor do segundo;
- Minutos - soma o valor da hora ao valor dos minutos;
- Segundos - soma o valor do minuto ao valor do segundo.
 */

int main(int argc, char *argv[]) {
	
	// 1. FALTA UTILIZAR STRUCT
	
	int hr = 10;
	int min = 59;
	int seg = 58;
	
	int *pH = &hr;	
	int *pM = &min;
	int *pS = &seg;

	
	printf("Hora: %i:%i:%i",*pH, *pM, *pS);

	
	
	
	
	
	
	
	
	return 0;
}
