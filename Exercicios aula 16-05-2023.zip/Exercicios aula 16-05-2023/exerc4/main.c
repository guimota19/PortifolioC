#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
			
	int x = 10;
	double y = 20.50;
	char z = 'a';
	
	int *pX = &x;
	double *pY = &y;
	char *pZ = &z;
	
	printf("Endereco x = %i - Valor x = %i \n", pX, *pX);
	printf("Endereco y = %e - Valor y = %e \n", pY, *pY);
	printf("Endereco z = %c - Valor z = %c ", pZ, *pZ);
	
	
	
	
	
	
	
	
	return 0;
}
