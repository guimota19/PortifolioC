#include <stdio.h>
#include <stdlib.h>

/* P O N T E I R O */

int main(int argc, char *argv[]) {
	
	int x;
	x = 10;
	
	printf("%i\n",&x);	// o & serve para mostrar o local da memoria de x
	
	printf("%i\n",x); // mostrar� o valor 10
	
	
	
	
	
	
	return 0;
}
