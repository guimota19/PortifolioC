#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {


	int x = 10;
	double y = 20.50;
	char z = 'a';
	
	int *pX = &x;	
	double *pY = &y;
	char *pZ = &z;

	double soma = *pX + *pY;
	
	printf("Valor x = %f\n",soma);


	
	return 0;
}
