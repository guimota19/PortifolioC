#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	
	int x = 10;
	int *ponteiro;
	
	ponteiro = &x;
	
	int y = 20;
	*ponteiro = y;
	
	printf("%i %i\n", x, y);		// imprimira 20

	printf("%i %i\n", &x, &y);		// imprimira endere�o da memoria
	
	return 0;
}
